
package survivaltext;
import java.util.Scanner;
import java.util.Random;
public class Survivaltext {

    
    public static void main(String[] args) {
        int firewood = 0;
        int water = 0;
        int food = 0;
        int night = 0;
        Scanner input = new Scanner(System.in); 
        String day = "day/s";
        Random rand = new Random();
       
        
        System.out.println("You are on a island, if you survive for 3 days someone will come and get you, but for now you're on your own");
        System.out.println("you are now walking forward");
        System.out.println("As you continue your walk there are three different paths which one will you take, 1, 2, 3");
        int paths = input.nextInt();
        switch(paths){
            case(1):
                System.out.println("You find a water bottle "
                        + "with more then enough water for you to survive");
                int water_bottle = water + 10;
                if (firewood<1){
                    System.out.println("you have no wood for the fire it's going to start getting cold soon "
                            + "\n to survive you need to find the wood");
                    System.out.println("you begin walking back to the orginal area of the three different paths");
                    System.out.println("You must now choose between the two other paths if you get firewood for the night you'll lose health, 1 or 2");
                    int paths2 = input.nextInt();
                    switch(paths2){
                        case(1):
                            System.out.println("You have managed to get the firewood, you have manged to stay alive in the night");
                            night++;
                            water_bottle--;
                            System.out.println(night + day +" you need to find food, if you don't find any you will go into shock and die");
                            System.out.println("Out of nowhere two boxes have arrived behind you, both boxes is the same code but the code can only be used once");
                            System.out.println("there is also a note, one says it contains food enough for a week, the other contains deadly scorpions");
                            System.out.println("You have chosen box?, 1 or 2");
                            int box12 = input.nextInt();
                            switch(box12){
                                case(1):
                                    System.out.println("You have chosen the deadly scorpion"
                                            + "You get Stung");
                                    System.out.println("Game over");
                                    System.out.println("You managed to survive for:" + night + day);
                                    break;
                                case(2):
                                    System.out.println("you have chosen the food box, you will be able to survive one more night");
                                    night++;
                                    water_bottle--;
                                    food++;
                                    System.out.println(night + day +" this is your last day on the island"
                                            + "however out of nowhere another human pops up");
                                    System.out.println("you can choose to be friends or scare him away, what will you choose, type, Friends or Nothing");
                                    String FN = input.next();
                                    if (FN.equals("Friends")){
                                        System.out.println("He stole all of your supplies and ran away."
                                                + "You then died before they could save you, you had " + water_bottle + " and");
                                        System.out.println("you managed to survive " + night + " days");
                                    }
                                    else{
                                        System.out.println("the man went away and you later got rescued and surived");
                                        night++;
                                        System.out.println("you managed to survive " + night + day);
                                        break;
                                    }
                                   
                            }
                            break;
                        case(2):
                            System.out.println("you did't get the wood, you froze in the night");
                            System.out.println("you managed to survive for" + night + day);
                           break; 
                        default:
                            System.out.println("You did not choose correctly, you die");
                            
                    }
                }
                break;
                
        
            case(2):
                System.out.println("You find some wood, you can survive the cold but you need to find food");
                firewood++;
                if (food < 1){
                    System.out.println("you have no food your going to get hungry soon "
                            + "\n to survive you need to find food");
                    System.out.println("You can't walk back something propels you forward");
                    System.out.println("you start walking even further on your path");
                    System.out.println("You see a many different boxes box on your Journey, they are labeled 1 and 2");
                    int furtherpush = input.nextInt();
                    switch(furtherpush){
                        case(1):
                            System.out.println("You have managed to get food, you have managed to stay alive in the night");
                            night++;
                            firewood++;
                            System.out.println(day+ " " + night +" you need to find water, if you don't find any you will dehydrate");
                            System.out.println("Out of nowhere two notes have arrived");
                            System.out.println("On a note, it says there is a box full of water bottles allowing you to surivve your journey, however on the other you will gain venomous snakes");
                            System.out.println("You have chosen note?, 1 or 2");
                            int note12 = input.nextInt();
                            switch(note12){
                                case(1):
                                    System.out.println("You have chosen the venomous snakes"
                                            + "You got poisoned");
                                    System.out.println("Game over");
                                    System.out.println("You managed to survive for:" + night + day);
                                    break;
                                case(2):
                                    System.out.println("you have chosen the box filled with water bottles, you will be able to survive for the rest of your journey");
                                    night++;
                                    System.out.println(night + day +" this is your last day on the island"
                                            + "You wake up feeling refreshed, but to a wolf standing on your chest");
                                    System.out.println("You can choose to play DEAD or if you want you can PATT the wolf");
                                    String Wolf = input.next();
                                    if (Wolf.equals("PATT")){
                                        System.out.println("The wolf was scared by you patting him, ...");
                                        System.out.println("you managed to survive " + night + " days");
                                    }
                                    else{
                                        System.out.println("You played dead and managed to get the wolf away from you!,"
                                                + "you were then rescued");
                                        night++;
                                        System.out.println("you managed to survive " + night + day);
                                        break;
                                    }                                    
                            }
                            case(2):
                                  System.out.println("unfortunatley you didn't get the right box...");
                                  System.out.println("You managed to survive for " + night + " " + day );
                                default:
                                    System.out.println("you didn't choose a box?, you eventually wither away");
                                    System.out.println("you managed to survive for:" + night + " " + day );

                            break;
                
            case(3):
                System.out.println("You find some food");
                food++;
                System.out.println("You need to find some wood to survive the night");
                if (firewood < 1){
                    System.out.println("you have no wood and no tools to gather it"
                            + "\n to survive you need to find wood otherwise you won't get past the night");
                    System.out.println("behind the box containing food you find a strange annotated map");
                    System.out.println("there are two different locations highlighted, it says one contains ");
                    System.out.println("You see a many different boxes box on your Journey, they are labeled 1 and 2");
                    System.out.println("what will you choose?");
                    int location12 = input.nextInt();
                    switch(location12){
                        case(1):
                            System.out.println("You have managed to get wood, you have manged to stay alive in the night the fire keeps you warm");
                            night++;
                            firewood++;
                            System.out.println(day+ " " + night +" you need to find water, if you don't find any you will dehydrate");
                            System.out.println("You begin walking in hope that you can find a fresh water source");
                            System.out.println("you find a lake, but as you begin walking to the lake you see something strange moving in the water and with every step it moves closer to you");
                            System.out.println("what will you do, if you don't get a drink you might fall into a coma");
                            System.out.println("1 you end up drinking from the lake, see what happens"
                                    + "2 you walk away from the lake");
                            int nextmove = input.nextInt();
                            switch(nextmove){
                                case(1):
                                    System.out.println("You have chosen to not drink from the lake you might fall into a coma random");
                                    int coma = rand.nextInt(2);
                                    if (coma == 2){
                                        System.out.println("You managed to survive for:" + night + day);
                                    break;
                                    }
                                    else{
                                        System.out.println("somehow you don't fall into a coma, you're lucky");
                                        System.out.println("however when you go to lie down...");
                                        System.out.println("You managed to survive " + night + " " + day);
                                    }
                                case(2):
                                    System.out.println("you have chosen to drink the water in the lake,"
                                            + "with the strange moving fish propelling itself towards you, it becomes apparent its no harm at all,"
                                            + "it's a goldfish? ");
                                    night++;
                                    System.out.println(night + day +" this is your last day on the island"
                                            + "You wake up however your food is gone, there are tracks left to follow");
                                    System.out.println("You can choose to follow the tracks(1) or ignnore and stay safe(2)");
                                    String tracks = input.next();
                                    if (tracks.equals("1")){
                                        System.out.println("You proceeded to follow the tracks which led you to a cold wet cave");
                                        System.out.println("Suddenly you get struck on the head and ...");
                                        System.out.println("you managed to survive " + night + " days");
                                    }
                                    else{
                                        System.out.println("You ignored the tracks and the missing food and later was rescued ");
                                        night++;
                                        System.out.println("you managed to survive " + night + day);
                                    }
                                default:
                                    System.out.println("well you didn't do anything and you're safe");
                                    System.out.println("you managed to survive for:" + night + " " + day );
                                    
                            }
                        case(2):
                            System.out.println("you didn't get any wood you froze in the night");
                            System.out.println("you managed to survive for:" + night + " " + day );
            
            default:
                System.out.println("You didn't choose a path, you gained nothing and later died");
                
            
        }
                    break;
    }
    
}
}
}
    }
}
